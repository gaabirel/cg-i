import src.controller.Cena;
import src.controller.MainController;
import src.controller.Renderizador;
import src.view.*;

public class Main {
    
    @SuppressWarnings("unused")
    public static void main(String[] args) {
        System.out.println("Programa inicializando...");
        Cena cena = new Cena(); //inicializa os objetos da cena
        int larguraJanela = 800;
        int alturaJanela = 800;
        double larguraWindow = 2.0;
        double alturaWindow = 2.0;
        double distanciaCamera = 5.0; 

        Renderizador renderizador = new Renderizador(cena, larguraWindow, alturaWindow, distanciaCamera, larguraJanela, alturaJanela);
        Janela janela = new Janela(larguraJanela, alturaJanela);
        MainController mainController  = new MainController(janela, renderizador);
        
    }

}
