package src.controller;

import java.awt.image.BufferedImage;

import src.view.Janela;

public class MainController {
    
    Janela janela;
    Renderizador renderizador;
    
    public MainController(Janela janela, Renderizador renderizador){
        this.janela = janela;
        this.renderizador = renderizador;
    }

    public void inicializar(){
        BufferedImage canvas = renderizador.getCanvas();
        janela
    }
}
