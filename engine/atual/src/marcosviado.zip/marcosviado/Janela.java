package src.view;

import java.awt.*;
import java.awt.image.BufferedImage;
import javax.swing.*;


public class Janela extends JFrame {
    
    private int nCol; // número de colunas do canvas
    private int nLin; // número de linhas do canvas
    private BufferedImage canvas; // tela a ser pintadA
    private RenderPanel renderPanel; // Painel customizado para renderização

    public Janela(int nCol, int nLin) {
        //Config da window na cena
        this.nCol = nCol;
        this.nLin = nLin;
        this.canvas = new BufferedImage(nCol, nLin, BufferedImage.TYPE_INT_RGB);
        

        //Configura o JFrame
        setTitle("Esfera lumiada");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(nCol, nLin);
        
        adicionarComponentes();
        setVisible(true);

    }

    public void adicionarComponentes(){
        //Painel customizado para renderizar a imagem
        renderPanel = new RenderPanel();
        renderPanel.setFocusable(true);

        /* 
        //Um listener do teclado para realizar o movimento das esferas
        TecladoListener tecladoListener = new TecladoListener(objetos, luzes.get(0).getPosicao(), this);
        renderPanel.addKeyListener(tecladoListener);
        renderPanel.setLayout(new BoxLayout(renderPanel, BoxLayout.PAGE_AXIS));

        MouseListener mouseListener = new MouseListener(this, objetos);
        renderPanel.addMouseListener(mouseListener);
        */
        add(renderPanel); // Adiciona o painel ao JFrame
    
    }

    public void atualizarCanvas(BufferedImage canvas){
        this.canvas = canvas;
        repaint();
    }

    private class RenderPanel extends JPanel {
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(canvas, 0, 0, null); // Desenha o canvas atualizado

        }

    }


}
